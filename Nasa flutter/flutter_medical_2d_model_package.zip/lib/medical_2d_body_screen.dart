import 'dart:math' as math;
import 'package:flutter/material.dart';

/// ============================================================================
/// المجسم الطبي التفاعلي ثنائي الأبعاد (2D X-Ray & Realistic Organs) لـ Flutter
/// ============================================================================
/// خطوات التركيب في مشروع Flutter الخاص بك:
/// 1. فك ضغط ملف (flutter_medical_2d_model_package.zip) المرفق وانسخ مجلد
///    `assets/images/` إلى جذر مشروع Flutter الخاص بك.
/// 2. أضف المسار التالي داخل ملف `pubspec.yaml`:
///    flutter:
///      assets:
///        - assets/images/
/// 3. استدعِ الويدجت `Medical2DBodyScreen()` داخل تطبيقك.
/// ============================================================================

enum VitalStatus {
  normal,   // أخضر: تمام (طبيعي)
  warning,  // أصفر: ممكن تحصل مشكلة (تحذير)
  critical, // أحمر: مشكلة خطيرة (حرج)
}

class OrganModel {
  final String id;
  final String enName;
  final String arName;
  final String systemName;
  final String assetPath;
  final String vitalSignName;
  final String unit;
  final String normalRangeText;
  final double minVal;
  final double maxVal;
  double currentValue;
  final double presetNormal;
  final double presetWarning;
  final double presetCritical;

  // الإحداثيات النسبية (0.0 إلى 1.0) لموضع العضو والنقطة داخل مجسم الأشعة (نسبة 2:3)
  final double organCenterX;
  final double organCenterY;
  final double organWidthFactor;
  final double pointX;
  final double pointY;

  OrganModel({
    required this.id,
    required this.enName,
    required this.arName,
    required this.systemName,
    required this.assetPath,
    required this.vitalSignName,
    required this.unit,
    required this.normalRangeText,
    required this.minVal,
    required this.maxVal,
    required this.currentValue,
    required this.presetNormal,
    required this.presetWarning,
    required this.presetCritical,
    required this.organCenterX,
    required this.organCenterY,
    required this.organWidthFactor,
    required this.pointX,
    required this.pointY,
  });

  /// تحديد حالة الإشارات الحيوية (أخضر / أصفر / أحمر) بناءً على القراءة الحالية
  VitalStatus get status {
    switch (id) {
      case 'brain': // ضغط داخل الجمجمة ICP (الطبيعي 7 - 15 mmHg)
        if (currentValue >= 7 && currentValue <= 15) return VitalStatus.normal;
        if ((currentValue >= 16 && currentValue <= 22) || currentValue == 6) {
          return VitalStatus.warning;
        }
        return VitalStatus.critical;

      case 'lungs': // تشبع الأكسجين SpO2 (الطبيعي 95% - 100%)
        if (currentValue >= 95) return VitalStatus.normal;
        if (currentValue >= 90) return VitalStatus.warning;
        return VitalStatus.critical;

      case 'heart': // نبضات القلب BPM (الطبيعي 60 - 100)
        if (currentValue >= 60 && currentValue <= 100) return VitalStatus.normal;
        if ((currentValue > 100 && currentValue <= 125) ||
            (currentValue >= 50 && currentValue < 60)) {
          return VitalStatus.warning;
        }
        return VitalStatus.critical;

      case 'liver': // إنزيمات الكبد ALT (الطبيعي 10 - 40 U/L)
        if (currentValue <= 40) return VitalStatus.normal;
        if (currentValue <= 85) return VitalStatus.warning;
        return VitalStatus.critical;

      case 'kidneys': // معدل الترشيح الكبيبي eGFR (الطبيعي >= 90 mL/min)
      default:
        if (currentValue >= 90) return VitalStatus.normal;
        if (currentValue >= 60) return VitalStatus.warning;
        return VitalStatus.critical;
    }
  }

  String get statusTitle {
    switch (status) {
      case VitalStatus.normal:
        return 'أخضر — تمام (الإشارات الحيوية طبيعية)';
      case VitalStatus.warning:
        return 'أصفر — تحذير (ممكن تحصل مشكلة)';
      case VitalStatus.critical:
        return 'أحمر — خطر! (مشكلة خطيرة تتطلب تدخلاً)';
    }
  }

  String get statusExplanation {
    switch (id) {
      case 'lungs':
        if (status == VitalStatus.normal) {
          return 'نسبة تشبع الأكسجين بالدم (SpO₂) ممتازة وكفاءة تبادل الغازات بالرئتين سليمة.';
        } else if (status == VitalStatus.warning) {
          return 'انخفاض طفيف في تشبع الأكسجين مع تسارع في التنفس؛ يحتاج المريض إلى متابعة.';
        } else {
          return 'نقص حاد وخطير في الأكسجين (Hypoxemia)؛ يلزم التدخل الطبي وإمداد الأكسجين فوراً.';
        }
      case 'heart':
        if (status == VitalStatus.normal) {
          return 'نبضات القلب منتظمة وفي النطاق الطبيعي (60-100 نبضة/دقيقة) وضخ الدم مستقر.';
        } else if (status == VitalStatus.warning) {
          return 'تسارع أو عدم انتظام متوسط في ضربات القلب؛ يُنصح بمراقبة تخطيط القلب ECG.';
        } else {
          return 'اضطراب حاد وخطير في معدل ضربات القلب يهدد كفاءة التروية الدموية!';
        }
      case 'brain':
        if (status == VitalStatus.normal) {
          return 'ضغط داخل الجمجمة (ICP) والتروية العصبية للمخ وموجات EEG في الحالة الطبيعية.';
        } else if (status == VitalStatus.warning) {
          return 'بداية ارتفاع في ضغط الجمجمة وإجهاد عصبي يحتاج إلى متابعة طبية.';
        } else {
          return 'ارتفاع خطير في ضغط داخل الجمجمة يتطلب تدخلاً طبياً عاجلاً!';
        }
      case 'liver':
        if (status == VitalStatus.normal) {
          return 'مستوى إنزيمات الكبد (ALT) ونسبة البيليروبين في الحدود الطبيعية السليمة.';
        } else if (status == VitalStatus.warning) {
          return 'ارتفاع متوسط في إنزيمات الكبد يشير إلى إجهاد كبدي يحتاج لفحص ومتابعة.';
        } else {
          return 'ارتفاع حاد وخطير في إنزيمات الكبد يشير إلى التهاب أو قصور كبدي حاد!';
        }
      case 'kidneys':
      default:
        if (status == VitalStatus.normal) {
          return 'معدل الترشيح الكبيبي (eGFR) ووظائف الكليتين في ترشيح الدم ممتازة.';
        } else if (status == VitalStatus.warning) {
          return 'انخفاض أولي في كفاءة ترشيح الكلى؛ يُنصح بضبط السوائل ومتابعة الكرياتينين.';
        } else {
          return 'انخفاض حاد وخطير في وظائف الكلى وترشيح الدم يتطلب رعاية طبية فورية!';
        }
    }
  }
}

class Medical2DBodyScreen extends StatefulWidget {
  const Medical2DBodyScreen({super.key});

  @override
  State<Medical2DBodyScreen> createState() => _Medical2DBodyScreenState();
}

class _Medical2DBodyScreenState extends State<Medical2DBodyScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulseController;
  late final List<OrganModel> _organs;
  String _selectedOrganId = 'lungs';
  bool _colorAllOrgans = false;
  bool _zoomTorso = false;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat();

    _organs = [
      OrganModel(
        id: 'brain',
        enName: 'BRAIN',
        arName: 'المخ (Brain)',
        systemName: 'الجهاز العصبي المركزي',
        assetPath: 'assets/images/organ_brain.png',
        vitalSignName: 'ضغط داخل الجمجمة (ICP)',
        unit: 'mmHg',
        normalRangeText: '7 - 15 mmHg',
        minVal: 5,
        maxVal: 35,
        currentValue: 11,
        presetNormal: 11,
        presetWarning: 19,
        presetCritical: 28,
        organCenterX: 0.500,
        organCenterY: 0.077,
        organWidthFactor: 0.106,
        pointX: 0.500,
        pointY: 0.077,
      ),
      OrganModel(
        id: 'lungs',
        enName: 'LUNGS',
        arName: 'الرئتان (Lungs)',
        systemName: 'الجهاز التنفسي والأكسجة',
        assetPath: 'assets/images/organ_lungs.png',
        vitalSignName: 'تشبع الأكسجين بالدم (SpO₂)',
        unit: '%',
        normalRangeText: '95% - 100%',
        minVal: 75,
        maxVal: 100,
        currentValue: 98,
        presetNormal: 98,
        presetWarning: 92,
        presetCritical: 83,
        organCenterX: 0.500,
        organCenterY: 0.254,
        organWidthFactor: 0.218,
        pointX: 0.420,
        pointY: 0.248,
      ),
      OrganModel(
        id: 'heart',
        enName: 'HEART',
        arName: 'القلب (Heart)',
        systemName: 'الجهاز الدوري والقلب',
        assetPath: 'assets/images/organ_heart.png',
        vitalSignName: 'معدل نبضات القلب (HR)',
        unit: 'BPM',
        normalRangeText: '60 - 100 BPM',
        minVal: 40,
        maxVal: 165,
        currentValue: 76,
        presetNormal: 76,
        presetWarning: 114,
        presetCritical: 148,
        organCenterX: 0.518,
        organCenterY: 0.268,
        organWidthFactor: 0.085,
        pointX: 0.520,
        pointY: 0.269,
      ),
      OrganModel(
        id: 'liver',
        enName: 'LIVER',
        arName: 'الكبد (Liver)',
        systemName: 'الجهاز الهضمي والأيض',
        assetPath: 'assets/images/organ_liver.png',
        vitalSignName: 'إنزيمات الكبد (ALT)',
        unit: 'U/L',
        normalRangeText: '10 - 40 U/L',
        minVal: 10,
        maxVal: 160,
        currentValue: 26,
        presetNormal: 26,
        presetWarning: 64,
        presetCritical: 132,
        organCenterX: 0.465,
        organCenterY: 0.334,
        organWidthFactor: 0.132,
        pointX: 0.442,
        pointY: 0.333,
      ),
      OrganModel(
        id: 'kidneys',
        enName: 'KIDNEYS',
        arName: 'الكليتان (Kidneys)',
        systemName: 'الجهاز البولي وترشيح الدم',
        assetPath: 'assets/images/organ_kidneys.png',
        vitalSignName: 'معدل الترشيح الكبيبي (eGFR)',
        unit: 'mL/min',
        normalRangeText: '90 - 120 mL/min',
        minVal: 15,
        maxVal: 120,
        currentValue: 102,
        presetNormal: 102,
        presetWarning: 72,
        presetCritical: 35,
        organCenterX: 0.500,
        organCenterY: 0.389,
        organWidthFactor: 0.158,
        pointX: 0.560,
        pointY: 0.389,
      ),
    ];
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  OrganModel get _selectedOrgan =>
      _organs.firstWhere((o) => o.id == _selectedOrganId);

  /// الألوان حسب الحالة (أخضر: تمام، أصفر: ممكن تحصل مشكلة، أحمر: مشكلة خطيرة)
  Color _getStatusColor(VitalStatus status) {
    switch (status) {
      case VitalStatus.normal:
        return const Color(0xFF10B981); // أخضر Emerald
      case VitalStatus.warning:
        return const Color(0xFFF59E0B); // أصفر Amber
      case VitalStatus.critical:
        return const Color(0xFFEF4444); // أحمر Red
    }
  }

  Color _getPanelBgColor(VitalStatus status) {
    switch (status) {
      case VitalStatus.normal:
        return const Color(0xFF064E3B).withValues(alpha: 0.85);
      case VitalStatus.warning:
        return const Color(0xFF78350F).withValues(alpha: 0.88);
      case VitalStatus.critical:
        return const Color(0xFF7F1D1D).withValues(alpha: 0.90);
    }
  }

  /// مصفوفة تلوين العضو الحقيقي (ColorFilter.matrix) مع الحفاظ على تفاصيله ثلاثية الأبعاد
  ColorFilter _getOrganColorMatrix(VitalStatus status) {
    switch (status) {
      case VitalStatus.normal: // تلوين أخضر طبي
        return const ColorFilter.matrix(<double>[
          0.15, 0.15, 0.05, 0, 5,
          0.35, 0.85, 0.20, 0, 30,
          0.10, 0.35, 0.25, 0, 15,
          0,    0,    0,    1, 0,
        ]);
      case VitalStatus.warning: // تلوين أصفر تحذيري
        return const ColorFilter.matrix(<double>[
          0.65, 0.55, 0.10, 0, 45,
          0.45, 0.50, 0.08, 0, 25,
          0.05, 0.05, 0.05, 0, 0,
          0,    0,    0,    1, 0,
        ]);
      case VitalStatus.critical: // تلوين أحمر خطر
        return const ColorFilter.matrix(<double>[
          0.85, 0.35, 0.15, 0, 55,
          0.08, 0.08, 0.04, 0, 0,
          0.08, 0.05, 0.05, 0, 5,
          0,    0,    0,    1, 0,
        ]);
    }
  }

  @override
  Widget build(BuildContext context) {
    final activeOrgan = _selectedOrgan;
    final activeStatus = activeOrgan.status;
    final activeColor = _getStatusColor(activeStatus);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFF040914),
        appBar: AppBar(
          backgroundColor: const Color(0xFF0A1428),
          elevation: 0,
          title: const Text(
            'المجسم الطبي التفاعلي 2D (Flutter)',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
          ),
          actions: [
            IconButton(
              tooltip: _zoomTorso ? 'عرض الجسم بالكامل' : 'تقريب منطقة الأعضاء',
              icon: Icon(_zoomTorso ? Icons.zoom_out_map : Icons.zoom_in),
              onPressed: () => setState(() => _zoomTorso = !_zoomTorso),
            ),
            IconButton(
              tooltip: _colorAllOrgans
                  ? 'تلوين العضو المحدد فقط'
                  : 'تلوين كل الأعضاء حسب حالتها',
              icon: Icon(
                _colorAllOrgans ? Icons.palette : Icons.palette_outlined,
                color: _colorAllOrgans ? Colors.amberAccent : Colors.white,
              ),
              onPressed: () =>
                  setState(() => _colorAllOrgans = !_colorAllOrgans),
            ),
          ],
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // شريط الاختيار السريع للأعضاء الـ 5
                SizedBox(
                  height: 58,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: _organs.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 8),
                    itemBuilder: (context, index) {
                      final org = _organs[index];
                      final isSel = org.id == _selectedOrganId;
                      final stColor = _getStatusColor(org.status);
                      return GestureDetector(
                        onTap: () => setState(() => _selectedOrganId = org.id),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 250),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 8),
                          decoration: BoxDecoration(
                            color: isSel
                                ? const Color(0xFF1E293B)
                                : const Color(0xFF0F172A),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: isSel
                                  ? Colors.lightBlueAccent
                                  : Colors.white12,
                              width: isSel ? 2 : 1,
                            ),
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 10,
                                height: 10,
                                decoration: BoxDecoration(
                                  color: stColor,
                                  shape: BoxShape.circle,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    org.arName,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12,
                                    ),
                                  ),
                                  Text(
                                    '${org.currentValue.toInt()} ${org.unit}',
                                    style: const TextStyle(
                                      color: Colors.white70,
                                      fontSize: 11,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),

                const SizedBox(height: 14),

                // المجسم التفاعلي بالأشعة السينية + الأعضاء الـ 5 الحقيقية + الـ 5 نقاط
                Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 380),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.black,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: Colors.lightBlueAccent.withValues(alpha: 0.35),
                          width: 1.5,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: activeColor.withValues(alpha: 0.20),
                            blurRadius: 24,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      clipBehavior: Clip.antiAlias,
                      child: AspectRatio(
                        aspectRatio: 2 / 3,
                        child: LayoutBuilder(
                          builder: (context, constraints) {
                            final W = constraints.maxWidth;
                            final H = constraints.maxHeight;

                            return AnimatedScale(
                              scale: _zoomTorso ? 1.72 : 1.0,
                              alignment: const Alignment(0.0, -0.52),
                              duration: const Duration(milliseconds: 450),
                              curve: Curves.easeOutCubic,
                              child: Stack(
                                clipBehavior: Clip.none,
                                children: [
                                  // 1. صورة مجسم الأشعة السينية للجسم بالكامل
                                  Positioned.fill(
                                    child: Image.asset(
                                      'assets/images/xray_body_clean.jpg',
                                      fit: BoxFit.contain,
                                    ),
                                  ),

                                  // 2. طبقة الأعضاء الـ 5 الحقيقية (يتغير لون العضو عند الضغط عليه)
                                  ..._organs.map((organ) {
                                    final isSelected =
                                        organ.id == _selectedOrganId;
                                    final organW = W * organ.organWidthFactor;
                                    final shouldTint =
                                        isSelected || _colorAllOrgans;
                                    final organStatusColor =
                                        _getStatusColor(organ.status);

                                    return Positioned(
                                      left: (W * organ.organCenterX) -
                                          (organW / 2),
                                      top: (H * organ.organCenterY) -
                                          (organW / 2),
                                      width: organW,
                                      child: GestureDetector(
                                        onTap: () => setState(
                                            () => _selectedOrganId = organ.id),
                                        child: AnimatedScale(
                                          scale: isSelected ? 1.12 : 1.0,
                                          duration:
                                              const Duration(milliseconds: 300),
                                          child: Container(
                                            decoration: isSelected
                                                ? BoxDecoration(
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: organStatusColor
                                                            .withValues(
                                                                alpha: 0.65),
                                                        blurRadius: 18,
                                                        spreadRadius: 2,
                                                      ),
                                                    ],
                                                  )
                                                : null,
                                            child: shouldTint
                                                ? ColorFiltered(
                                                    colorFilter:
                                                        _getOrganColorMatrix(
                                                            organ.status),
                                                    child: Image.asset(
                                                      organ.assetPath,
                                                      fit: BoxFit.contain,
                                                    ),
                                                  )
                                                : Image.asset(
                                                    organ.assetPath,
                                                    fit: BoxFit.contain,
                                                  ),
                                          ),
                                        ),
                                      ),
                                    );
                                  }),

                                  // 3. النقاط التفاعلية الـ 5 (Hotspot Points) على الأعضاء
                                  ..._organs.map((organ) {
                                    final isSelected =
                                        organ.id == _selectedOrganId;
                                    final pointColor =
                                        _getStatusColor(organ.status);
                                    const double hitSize = 36.0;

                                    return Positioned(
                                      left:
                                          (W * organ.pointX) - (hitSize / 2),
                                      top:
                                          (H * organ.pointY) - (hitSize / 2),
                                      width: hitSize,
                                      height: hitSize,
                                      child: GestureDetector(
                                        onTap: () => setState(
                                            () => _selectedOrganId = organ.id),
                                        child: AnimatedBuilder(
                                          animation: _pulseController,
                                          builder: (context, _) {
                                            final pulse =
                                                _pulseController.value;
                                            return Stack(
                                              alignment: Alignment.center,
                                              children: [
                                                // حلقة النبض المضيئة
                                                Container(
                                                  width: 14 + (pulse * 18),
                                                  height: 14 + (pulse * 18),
                                                  decoration: BoxDecoration(
                                                    shape: BoxShape.circle,
                                                    color: pointColor
                                                        .withValues(
                                                            alpha: (1.0 -
                                                                    pulse) *
                                                                0.55),
                                                  ),
                                                ),
                                                // النقطة الأساسية
                                                Container(
                                                  width: isSelected ? 16 : 12,
                                                  height: isSelected ? 16 : 12,
                                                  decoration: BoxDecoration(
                                                    shape: BoxShape.circle,
                                                    color: pointColor,
                                                    border: Border.all(
                                                      color: Colors.white,
                                                      width:
                                                          isSelected ? 2.5 : 1.8,
                                                    ),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: pointColor,
                                                        blurRadius: 8,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            );
                                          },
                                        ),
                                      ),
                                    );
                                  }),
                                ],
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 18),

                // ===============================================================
                // لوحة حالة الإشارات الحيوية (يتغير لونها بالكامل: أخضر / أصفر / أحمر)
                // ===============================================================
                AnimatedContainer(
                  duration: const Duration(milliseconds: 400),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: _getPanelBgColor(activeStatus),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: activeColor, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: activeColor.withValues(alpha: 0.35),
                        blurRadius: 20,
                        offset: const Offset(0, 8),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // رأس اللوحة: صورة العضو الحقيقي + اسم العضو + شارة الحالة
                      Row(
                        children: [
                          Container(
                            width: 68,
                            height: 68,
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: Colors.black87,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: Colors.white24),
                            ),
                            child: Image.asset(
                              activeOrgan.assetPath,
                              fit: BoxFit.contain,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  activeOrgan.systemName,
                                  style: const TextStyle(
                                    color: Colors.white70,
                                    fontSize: 12,
                                  ),
                                ),
                                Text(
                                  activeOrgan.arName,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w900,
                                    fontSize: 22,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: Colors.black38,
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(color: Colors.white24),
                                  ),
                                  child: Text(
                                    activeOrgan.statusTitle,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 14),

                      // صندوق القراءة الحيوية الأساسية + رسم الموجة الحيوية
                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: Colors.black45,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: Colors.white12),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Flexible(
                                  child: Text(
                                    'الإشارة الحيوية: ${activeOrgan.vitalSignName}',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13,
                                    ),
                                  ),
                                ),
                                Text(
                                  'الطبيعي: ${activeOrgan.normalRangeText}',
                                  style: const TextStyle(
                                    color: Colors.white70,
                                    fontSize: 11,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.baseline,
                              textBaseline: TextBaseline.alphabetic,
                              children: [
                                Text(
                                  '${activeOrgan.currentValue.toInt()}',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w900,
                                    fontSize: 40,
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  activeOrgan.unit,
                                  style: const TextStyle(
                                    color: Colors.white70,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            // مخطط الموجة الحيوية المباشر
                            SizedBox(
                              height: 48,
                              width: double.infinity,
                              child: AnimatedBuilder(
                                animation: _pulseController,
                                builder: (context, _) {
                                  return CustomPaint(
                                    painter: _VitalWavePainter(
                                      phase: _pulseController.value *
                                          2 *
                                          math.pi,
                                      color: activeColor,
                                      organId: activeOrgan.id,
                                    ),
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 10),

                      // تفسير الحالة الطبية
                      Text(
                        activeOrgan.statusExplanation,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          height: 1.4,
                        ),
                      ),

                      const Divider(color: Colors.white24, height: 24),

                      // أزرار اختبار الحالات الثلاث (أخضر / أصفر / أحمر) + شريط التمرير
                      const Text(
                        'محاكاة القراءة الحيوية وحالة اللوحة:',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF059669),
                                foregroundColor: Colors.white,
                                padding:
                                    const EdgeInsets.symmetric(vertical: 10),
                              ),
                              onPressed: () => setState(() => activeOrgan
                                  .currentValue = activeOrgan.presetNormal),
                              child: const Text('أخضر: تمام',
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold)),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFFD97706),
                                foregroundColor: Colors.white,
                                padding:
                                    const EdgeInsets.symmetric(vertical: 10),
                              ),
                              onPressed: () => setState(() => activeOrgan
                                  .currentValue = activeOrgan.presetWarning),
                              child: const Text('أصفر: تحذير',
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold)),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFFDC2626),
                                foregroundColor: Colors.white,
                                padding:
                                    const EdgeInsets.symmetric(vertical: 10),
                              ),
                              onPressed: () => setState(() => activeOrgan
                                  .currentValue = activeOrgan.presetCritical),
                              child: const Text('أحمر: خطر',
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold)),
                            ),
                          ),
                        ],
                      ),
                      Slider(
                        value: activeOrgan.currentValue,
                        min: activeOrgan.minVal,
                        max: activeOrgan.maxVal,
                        activeColor: Colors.white,
                        inactiveColor: Colors.white24,
                        onChanged: (val) {
                          setState(() {
                            activeOrgan.currentValue = val.roundToDouble();
                          });
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// رسام الموجة الحيوية المباشرة (ECG / SpO2 / EEG)
class _VitalWavePainter extends CustomPainter {
  final double phase;
  final Color color;
  final String organId;

  _VitalWavePainter({
    required this.phase,
    required this.color,
    required this.organId,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.2;

    final path = Path();
    final midY = size.height / 2;

    for (double x = 0; x <= size.width; x += 2) {
      final t = (x * 0.05) + phase;
      double yOffset = 0;

      if (organId == 'heart') {
        final cycle = t % (math.pi * 2);
        if (cycle > 2.8 && cycle < 3.1) {
          yOffset = -16;
        } else if (cycle >= 3.1 && cycle < 3.35) {
          yOffset = 11;
        } else {
          yOffset = math.sin(t) * 2.5;
        }
      } else if (organId == 'lungs') {
        yOffset = math.sin(t) * 11 + math.sin(t * 2) * 4;
      } else {
        yOffset = math.sin(t * 1.8) * 8 + math.cos(t * 3.4) * 4;
      }

      if (x == 0) {
        path.moveTo(x, midY + yOffset);
      } else {
        path.lineTo(x, midY + yOffset);
      }
    }

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _VitalWavePainter oldDelegate) =>
      oldDelegate.phase != phase ||
      oldDelegate.color != color ||
      oldDelegate.organId != organId;
}
